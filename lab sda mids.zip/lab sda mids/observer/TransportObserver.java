package observer;

// Observer Interface
public interface TransportObserver {
    void update(String message);
}
